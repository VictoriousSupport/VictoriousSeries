Victorious Series by [Jinx™](https://www.joduska.me/forum/user/1178097-mephistos/)
===




What is the [Victorious Series](https://github.com/VictoriousSupport/VictoriousSeries)?
---

> Leaguesharp Assembly of the support, by the support, for the support...


Supported Champion
---
![](http://static.trimword.com/Earth.png)

1. **Soraka**
 - Origin: Sophie's Soraka by ChewyMoon
 - Q/E Cast: OKTW Prediction
2. **Nami**
 - Origin: ElNami:ReBurrito by jQuery
 - Q Cast: OKTW Prediction
3. **Thresh**
 - Origin: Thresh - The ruler of the soul by Kaiser
 - Q Cast: OKTW Prediction
4. **Alistar**
 - Origin: ElAlistarReborn by jQuery
 - WQ Cast: jQuery
 - QW Cast: [Jinx™](https://www.joduska.me/forum/user/1178097-mephistos/)
5. **Lulu**
 - Origin: HeavenStrikeLulu by badao + Lulu# by Kortatu
 - Q Cast: OKTW Prediction
 - Q+E Cast: [Jinx™](https://www.joduska.me/forum/user/1178097-mephistos/)
6. Sona (WIP)
 - Origin: ElEasy by jQuery
7. Leona (WIP)
 - Origin: ElEasy by jQuery


Version History
---

  - [6.3.0.2]
    - 어셈블리 명칭 변경 (Victorious Support → Victorious Series)
    - 

  - [6.0.1.8]
    - GitHub 릴리즈
    - Tresh 통합 작업 완료
    - 로딩 출력 메세지 수정
    - 나미 궁극기(R) 로직 수정
